#include<iostream>
#include<fstream>
#include<cstdlib>
#include<string>
#include<iomanip>
using namespace std; 

class employee
  {
  	private : 
  		string name,id,age,ic,position,phone,salary,department,leave,perf;
  		
  	public :
  		employee()
  		{
  			name = " ";
  			id = " ";
			age = " ";
			ic = " ";
			position = " ";
			phone = " ";
			salary = " ";
			department = " ";
			leave = " ";
			perf = " ";
			
  		}
  		void setname(string n){ name = n;}
		void setid(string x){ id = x;}
		void setage(string a){ age = a;}
		void setic(string c){ ic= c;}
		void setposition(string p){ position = p;}
		void setphone(string ph){ phone = ph;}
		void setsalary(string s){ salary = s;}
		void setdepartment(string dept){ department = dept;}
  		void setleave(string l){ leave = l;}
  		void setperf(string pf){ perf = pf;}
  		
  		string getname(){return name;}
		string getid(){return id;}
  		string getage(){return age;}
  		string getic(){return ic;}
  		string getposition(){return position;}
  		string getphone(){return phone;}
  		string getsalary(){return salary;}
  		string getdepartment(){return department;}
  		string getleave(){return leave;}
  		string getperf(){return perf;}
  };
  
float evaluation()
{
	
	float w,x,y,z;
	float eva;
	
	cout<<"\n\n"<<right<<setw(52)<<"...............................................................................................................................................\n";
	cout<<setw(80)<<"COLLEAGUE EVALUATION"<<endl
	<<setw(52)<<"...............................................................................................................................................\n"
	<<right<<setw(60)<<"	1.VERY POOR"<<endl
	<<setw(58)<<"	2.POOR"<<endl
	<<setw(61)<<"	3.AVERAGE"<<endl
	<<setw(58)<<"	4.GOOD"<<endl
	<<setw(62)<<"	5.EXELLENT"<<endl<<endl;
	
	cout<<setw(80)<<"NAME : ..........."<<endl;
	cout<<setw(80)<<"ID   : ..........."<<endl<<endl
	
	<<setw(83)<<"----------------------------------------------------------------------------------------------------------------------------------------------\n";
	cout<<setw(85)<<"PLEASE EVALUATE YOUR COLLEAGUE\n"<<endl
	<<setw(83)<<"----------------------------------------------------------------------------------------------------------------------------------------------\n";
	
	cout<<setw(70)<<"	1.ATTITUDE : ";
	cin>>w;
	cout<<setw(78)<<"	2.WORK PERFORMANCE : ";
	cin>>x;
	cout<<setw(77)<<"	3.TEAMWORK : ";
	cin>>y;
	cout<<setw(75)<<"	4.SOCIAL SKILLS : ";
	cin>>z;	
	
	eva = (( w + x + y + z ) / 20 ) * 100 ;  
	
	cout<<"\n\n"<<right<<setw(90)<<"TOTAL % OF PEER EVALUATION : ";
	
	return eva;
	
}

void menu()
{
	cout<<right<<setw(83)<<"----------------------------------------------------------------------------------------------------------------------------------------------\n"
	<<setw(60)<<"-MENU-"<<endl
	<<setw(50)<<"	1.SEARCH EMPLOYEE"<<endl
	<<setw(60)<<"	2.EMPLOYEE'S' PROMOTION"<<endl
	<<setw(60)<<"	3.EMPLOYEE'S PERFORMANCE"<<endl
	<<setw(60)<<"	4.TERMINATE EMPLOYEE"<<endl;
	
}

int main()
{
	employee obj1[21];
	int i=0;
 string name,id,age,ic,position,phone,salary,department,leave,perf;
 
 
 ifstream inp("employee.txt");
 if(!inp)
 {
 	cout<<"Error, cannot find the file!";
 	exit(1);
 }
 
 cout<<left<<setw(37)<<"NAME"
 	<<left<<setw(7)<<"ID"
 	<<left<<setw(5)<<"AGE"
 	<<left<<setw(15)<<"IC"
 	<<left<<setw(15)<<"PHONE"
 	<<left<<setw(18)<<"POSITION"
 	<<left<<setw(15)<<"DEPARTMENT"
 	<<left<<setw(12)<<"SALARY(RM)"
	<<left<<setw(10)<<"LEAVE"
	<<left<<setw(5)<<"PERFORMANCE"<<endl;
 	
 	
 while (getline(inp,name,','))
 {
 	getline(inp,id,',');
 	getline(inp,age,',');
 	getline(inp,ic,',');
 	getline(inp,phone,',');
 	getline(inp,position,',');
 	getline(inp,department,',');
 	getline(inp,salary);
 	
 	obj1[i].setname(name);
 	obj1[i].setid(id);
 	obj1[i].setage(age);
 	obj1[i].setic(ic);
 	obj1[i].setphone(phone);
 	obj1[i].setposition(position );
 	obj1[i].setdepartment(department);
 	obj1[i].setsalary(salary);
 	obj1[i].setleave(leave);
 	obj1[i].setperf(perf);
 	
 		cout<<left<<setw(37)<<obj1[i].getname();
 		cout<<setw(7)<<obj1[i].getid();
 		cout<<setw(5)<<obj1[i].getage();
 		cout<<setw(15)<<obj1[i].getic();
 		cout<<setw(15)<<obj1[i].getphone();
 		cout<<setw(18)<<obj1[i].getposition();
 		cout<<setw(15)<<obj1[i].getdepartment();
 		cout<<setw(12)<<obj1[i].getsalary();
		cout<<setw(10)<<obj1[i].getleave();
		cout<<setw(5)<<obj1[i].getperf()<<endl;
 	
 /*	cout<<left<<setw(37)<<name
	 	<<setw(7)<<id
	 	<<setw(5)<<age<<setw(15)<<ic
		<<setw(15)<<phone<<setw(25)<<position<<setw(15)<<department
		<<setw(5)<<salary<<endl;
		*/
	i++;
 }
 
 
 
 	cout<<evaluation()<<endl;
 	menu();
 
 inp.close();
return 0;
}
